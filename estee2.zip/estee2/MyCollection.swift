//
//  MyCollection.swift
//  estee2
//
//  Created by Scholar on 8/17/22.
//

import UIKit

class MyCollection: UICollectionViewCell {
    
    
    @IBOutlet var myMakeupImage: UIImageView!
    
}
