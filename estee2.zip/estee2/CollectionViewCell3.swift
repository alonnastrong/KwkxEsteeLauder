//
//  CollectionViewCell3.swift
//  estee2
//
//  Created by Scholar on 8/18/22.
//

import UIKit

class CollectionViewCell3: UICollectionViewCell {
    
}
